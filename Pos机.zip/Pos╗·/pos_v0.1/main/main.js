'use strict';
    var inputs;                       //定义inputs变量  let与var的区别
    inputs = [
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00
  
        },
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000001',
          name: '雪碧',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000001',
          name: '雪碧',
          unit: '瓶',
          price: 3.00
        },
        {
          barcode: 'ITEM000004',
          name: '电池',
          unit: '个',
          price: 2.00
        }
      ];
    function printReceipt(inputs) {               
      var sum=0;
      var word="****/<没钱赚的商店/>收据****";
     	var kinds = [
     	{
     		    barcode: 'ITEM000000',
          	name: '可口可乐',
          	unit: '瓶',
          	price: 3.00
     	},
      {
          barcode: 'ITEM000001',
          name: '雪碧',
          unit: '瓶',
          price: 3.00
      },
      {
          barcode: 'ITEM000004',
          name: '电池',
          unit: '个',
          price: 2.00
        }
     	];
      for(var i= 0;i < kinds.length; i++){                   
        kinds[i].count=0;                            //使得数量为0；
      }
      for(var i=0;i<inputs.length;i++) {
        for(var j=0;j<kinds.length;j++)
        if(inputs[i].name == kinds[j].name) {
          kinds[j].count++;
        }
      }
      for(var i=0;i<kinds.length;i++){  
          word=word+'\n'+'名称：'+kinds[i].name+','+'数量：'+kinds[i].count+kinds[i].unit+'，'+'单价：'+kinds[i].price+'.00(元)'+'，'+'小计：'+kinds[i].price*kinds[i].count+'.00(元)';
          sum+=kinds[i].price*kinds[i].count;
      }
      console.log(word+'\n'+'----------------------------'+'\n'+'总计：'+sum+'.00'+'\n'
                  +'***************************');
    }
    printReceipt(inputs);