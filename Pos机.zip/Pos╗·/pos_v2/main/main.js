'use strict';
function printReceipt(inputs){
    var list=Item.all();             //与pos_v1_3rdlib的区别；
    var kinds = [list[1],list[3],list[5]];
    for(var i=0;i < kinds.length; i++){
      kinds[i].count=0;
    }
  for (var i=0; i<inputs.length;i++) {  
    for(var j = 0;j < kinds.length; j++){
      if(inputs[i]===kinds[j].barcode){                      //针对普通情况；
          kinds[j].count++;
      }
      else if(inputs[i].substring(0,inputs[i].indexOf('-'))===kinds[j].barcode){   //针对多个物品的情况；   substring() 方法用于提取字符串中介于两个指定下标之间的字符。 indexOf() 方法可返回某个指定的字符串值在字符串中首次出现的位置。
        var num=inputs[i].substring(inputs[i].indexOf('-')+1,inputs[i].length);   //读取条形码后面的数量；
        kinds[j].count=num;
      }
    }
  }
  var dazhe= Promotion.all();
  for(var a=0;a<kinds.length;a++) {
    kinds[a].save = 0;
  }
  var allsave=0;
  for(var i=0;i<kinds.length;i++){
    for(var j=0;j<3;j++){
      if(kinds[i].barcode==dazhe[0].barcodes[j]){
        if(kinds[i].count>=3){
          kinds[i].save = kinds[i].price;
        }
      }
    }
    allsave +=kinds[i].save;
  } 
  let dateDigitToString = num => num < 10 ? `0${num}` : num;             //加上let与省略let的区别
  const currentDate = new Date(),
  year = dateDigitToString(currentDate.getFullYear()),
  month = dateDigitToString(currentDate.getMonth() + 1),
  date = dateDigitToString(currentDate.getDate()),
  hour = dateDigitToString(currentDate.getHours()),
  minute = dateDigitToString(currentDate.getMinutes()),
  second = dateDigitToString(currentDate.getSeconds()),
  formattedDateString = `${year}年${month}月${date}日 ${hour}:${minute}:${second}`;
  var sum=0;           
  var word='***<没钱赚商店>收据***\n'+'打印时间：'+`${formattedDateString}`+'\n'+'----------------------';
  for(var i=0;i<kinds.length;i++){  
      sum+=kinds[i].price*kinds[i].count;
      word=word+'\n'+'名称：'+kinds[i].name+'，'+'数量：'+kinds[i].count+kinds[i].unit+'，'+'单价：'+(kinds[i].price).toFixed(2)+'(元)'+'，'+'小计：'+(kinds[i].price*kinds[i].count-kinds[i].save).toFixed(2)+'(元)';
      
  }
  console.log(word+'\n'+'----------------------'+'\n'+'总计：'+(sum-allsave).toFixed(2)+'(元)'+'\n'+'节省：'+allsave.toFixed(2)+'(元)'+'\n' +'**********************');
}

  