 'use strict'; 
    var inputs;                       //定义inputs变量  let与var的区别
    inputs = [
        {
          barcode: 'ITEM000000',
          name: '可口可乐',
          unit: '瓶',
          price: 3.00,
          count: 5
        },
        {
          barcode: 'ITEM000001',
          name: '雪碧',
          unit: '瓶',
          price: 3.00,
          count: 2
        },
        {
          barcode: 'ITEM000004',
          name: '电池',
          unit: '个',
          price: 2.00,
          count: 1
        }
      ];
    function printReceipt(inputs) {                 
          var sum=0;
          var word="***<没钱赚的商店>收据***";
          for(var i=0;i<inputs.length;i++){  
              word=word+'\n'+'名称：'+inputs[i].name+'，'+'数量：'+inputs[i].count+inputs[i].unit+'，'+'单价：'+inputs[i].price+'.00(元)'+'，'+'小计：'+inputs[i].price*inputs[i].count+'.00(元)';
              sum+=inputs[i].price*inputs[i].count;
          }
          console.log(word+'\n'+'----------------------------'+'\n'+'总计：'+sum+'.00'+'\n'
                      +'***************************');
        
    }
    printReceipt(inputs);



