'use strict';
var inputs = [
    'ITEM000000',
    'ITEM000000',
    'ITEM000000',
    'ITEM000000',
    'ITEM000000',
    'ITEM000001',
    'ITEM000001',
    'ITEM000004'
  ];
function printReceipt(inputs) {
    var list=loadAllItems();
    var kinds = [list[0],list[1],list[4]];
    for(var i= 0;i < kinds.length; i++){                   
        kinds[i].count=0;                            //使得数量为0；
    }
    for (var i = 0; i < inputs.length; i++) {  
        for(var j = 0;j < kinds.length; j++){
            if(inputs[i]==kinds[j].barcode){
                kinds[j].count++;
            }
        }
    }
        var sum=0;           
        var word="****/<没钱赚的商店/>收据****";
        for(var i=0;i<kinds.length;i++){  
            sum+=kinds[i].price*kinds[i].count;
            word=word+'\n'+'名称：'+kinds[i].name+','+'数量：'+kinds[i].count+kinds[i].unit+'，'+'单价：'+kinds[i].price+'.00(元)'+'，'+'小计：'+kinds[i].price*kinds[i].count+'.00(元)';
            
        }
        console.log(word+'\n'+'----------------------------'+'\n'+'总计：'+sum+'.00'+'\n'
                    +'***************************');
}
